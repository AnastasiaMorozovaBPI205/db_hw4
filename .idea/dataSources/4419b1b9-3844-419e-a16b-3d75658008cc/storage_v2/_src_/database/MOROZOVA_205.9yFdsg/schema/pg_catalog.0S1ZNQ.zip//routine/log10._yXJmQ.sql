create function log10(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function log10(numeric) is 'base 10 logarithm';

alter function log10(numeric) owner to "MOROZOVA_205";

